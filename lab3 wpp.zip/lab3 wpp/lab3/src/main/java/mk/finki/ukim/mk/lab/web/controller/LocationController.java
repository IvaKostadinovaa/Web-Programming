//package mk.finki.ukim.mk.lab.web.controller;
//
//import mk.finki.ukim.mk.lab.model.Location;
//import mk.finki.ukim.mk.lab.service.LocationService;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.List;
//
//@Controller
//@RequestMapping("/locations")
//public class LocationController {
//
//    private final LocationService locationService;
//
//    public LocationController(LocationService locationService) {
//        this.locationService = locationService;
//    }
//
//    @GetMapping
//    public String listLocations(Model model) {
//        List<Location> locations = locationService.listAll();
//        model.addAttribute("locations", locations);
//        return "listLocations";
//    }
//
//    @GetMapping("/add-form")
//    public String addLocationPage() {
//        return "add-location";
//    }
//
////    @PostMapping("/add")
////    public String saveLocation(@RequestParam String name, @RequestParam String address) {
////        locationService.save(name, address);
////        return "redirect:/locations";
////    }
//
//    @PostMapping("/add")
//    public String saveLocation(
//            @RequestParam(required = false) Long id,
//            @RequestParam String name,
//            @RequestParam String address,
//            @RequestParam String capacity,
//            @RequestParam String description
//    ) {
//        Location location = new Location(name, address, capacity, description);
//        locationService.save(location);
//        return "redirect:/locations";
//    }
//
//
//    @PostMapping("/delete/{id}")
//    public String deleteLocation(@PathVariable Long id) {
//        locationService.deleteById(id);
//        return "redirect:/locations";
//    }
//}

package mk.finki.ukim.mk.lab.web.controller;

import mk.finki.ukim.mk.lab.model.Location;
import mk.finki.ukim.mk.lab.service.LocationService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@Controller
@RequestMapping("/locations")
public class LocationController {

    private final LocationService locationService;

    public LocationController(LocationService locationService) {
        this.locationService = locationService;
    }

    @GetMapping
    public String listLocations(Model model) {
        List<Location> locations = locationService.listAll();
        model.addAttribute("locations", locations);
        return "listLocations";
    }

    @GetMapping("/add-form")
    public String addLocationPage(@RequestParam(required = false) Long id, Model model) {
        if (id != null) {
            Location location = locationService.findById(id)
                    .orElseThrow(() -> new RuntimeException("Location not found"));
            model.addAttribute("location", location);
        }
        return "add-location";
    }

    @PostMapping("/add")
    public String saveLocation(
            @RequestParam(required = false) Long id,
            @RequestParam String name,
            @RequestParam String address,
            @RequestParam String capacity,
            @RequestParam String description
    ) {
        Location location = new Location(name, address, capacity, description);
        location.setId(id); // Ако ID е null, Hibernate ќе го генерира
        locationService.save(location);
        return "redirect:/locations";
    }

    @PostMapping("/delete/{id}")
    public String deleteLocation(@PathVariable Long id) {
        locationService.deleteById(id);
        return "redirect:/locations";
    }
}
