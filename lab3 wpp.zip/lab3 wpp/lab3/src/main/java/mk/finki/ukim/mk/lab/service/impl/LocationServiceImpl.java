////package mk.finki.ukim.mk.lab.service.impl;
////
////import mk.finki.ukim.mk.lab.model.Location;
////import mk.finki.ukim.mk.lab.repository.impl.LocationRepository;
////import mk.finki.ukim.mk.lab.service.LocationService;
////import org.springframework.stereotype.Service;
////
////import java.util.List;
////import java.util.Optional;
////
////@Service
////public class LocationServiceImpl implements LocationService {
////
////    private final LocationRepository locationRepository;
////    //dodavame
////    //private final EventRepository eventRepository;
////
////
//////    public LocationServiceImpl(LocationRepository locationRepository, EventRepository eventRepository) {
//////        this.locationRepository = locationRepository;
//////        this.eventRepository = eventRepository;
//////    }
////public LocationServiceImpl(LocationRepository locationRepository) {
////    this.locationRepository = locationRepository;
////}
////
////    @Override
////    public List<Location> listAll() {
////        return locationRepository.findAll();
////    }
////
////    @Override
////    public Optional<Location> findById(long id) {
////        return locationRepository.findById(id);
////    }
////
//////    //dodavame
//////    @Override
//////    public void save(String name, String address) {
//////        locationRepository.save(new Location(name, address, "", ""));
//////    }
//////
//////    @Override
//////    public void deleteById(Long id) {
//////        // Бришење на поврзаните настани
//////        List<Event> events = eventRepository.findAll();
//////        events.removeIf(event -> event.getLocation().getId().equals(id));
//////        locationRepository.deleteById(id);
//////    }
////
////    @Override
////    public void deleteById(Long id) {
////        locationRepository.deleteById(id);
////    }
////
////    @Override
////    public void save(Location location) { // Промена тука
////        locationRepository.save(location);
////    }
////
////}
//
//
//package mk.finki.ukim.mk.lab.service.impl;
//
//import mk.finki.ukim.mk.lab.model.Location;
//import mk.finki.ukim.mk.lab.repository.jpa.LocationRepositoryjpa;
//import mk.finki.ukim.mk.lab.service.LocationService;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//import java.util.Optional;
//
//@Service
//public class LocationServiceImpl implements LocationService {
//
//    private final LocationRepositoryjpa locationRepository;
//
//    public LocationServiceImpl(LocationRepositoryjpa locationRepository) {
//        this.locationRepository = locationRepository;
//    }
//
//    @Override
//    public List<Location> listAll() {
//        return locationRepository.findAll();
//    }
//
//    @Override
//    public Optional<Location> findById(long id) {
//        return locationRepository.findById(id);
//    }
//
//    @Override
//    public void deleteById(Long id) {
//        locationRepository.deleteById(id);
//    }
//
//    @Override
//    public void save(Location location) {
//        locationRepository.save(location);
//    }
//}
//

package mk.finki.ukim.mk.lab.service.impl;

import mk.finki.ukim.mk.lab.model.Location;
import mk.finki.ukim.mk.lab.repository.jpa.LocationRepositoryjpa;
import mk.finki.ukim.mk.lab.service.LocationService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class LocationServiceImpl implements LocationService {

    private final LocationRepositoryjpa locationRepository;

    public LocationServiceImpl(LocationRepositoryjpa locationRepository) {
        this.locationRepository = locationRepository;
    }

    @Override
    public List<Location> listAll() {
        return locationRepository.findAll();
    }

    @Override
    public Optional<Location> findById(long id) {
        return locationRepository.findById(id);
    }

    @Override
    public void deleteById(Long id) {
        locationRepository.deleteById(id);
    }

    @Override
    public void save(Location location) {
        if (location.getId() != null && locationRepository.existsById(location.getId())) {
            // Ако постои ID, најди го постоечкиот запис и ажурирај го
            Location existingLocation = locationRepository.findById(location.getId())
                    .orElseThrow(() -> new RuntimeException("Location with ID " + location.getId() + " not found"));
            existingLocation.setName(location.getName());
            existingLocation.setAddress(location.getAddress());
            existingLocation.setCapacity(location.getCapacity());
            existingLocation.setDescription(location.getDescription());
            locationRepository.save(existingLocation);
        } else {
            // Ако ID не постои, креирај нов запис
            locationRepository.save(location);
        }
    }
}
