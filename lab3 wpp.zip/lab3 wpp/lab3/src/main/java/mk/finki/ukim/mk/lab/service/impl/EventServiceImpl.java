//package mk.finki.ukim.mk.lab.service.impl;
//
//import mk.finki.ukim.mk.lab.model.Event;
//import mk.finki.ukim.mk.lab.model.Location;
//import mk.finki.ukim.mk.lab.model.SavedBooking;
//import mk.finki.ukim.mk.lab.repository.impl.EventRepository;
//import mk.finki.ukim.mk.lab.repository.impl.LocationRepository;
//import mk.finki.ukim.mk.lab.repository.jpa.EventRepositoryjpa;
//import mk.finki.ukim.mk.lab.repository.jpa.LocationRepositoryjpa;
//import mk.finki.ukim.mk.lab.service.EventService;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//import java.util.Optional;
//
//@Service
//public class EventServiceImpl implements EventService {
//
//    private final EventRepositoryjpa eventRepository;
//    private final LocationRepositoryjpa locationRepository;
//
//    public EventServiceImpl(EventRepositoryjpa eventRepository,
//                            LocationRepositoryjpa locationRepository) {
//        this.eventRepository = eventRepository;
//        this.locationRepository = locationRepository;
//    }
//
//    @Override
//    public List<Event> listAll() {
//        return eventRepository.findAll();
//    }
//
//    @Override
//    public List<Event> searchEvents(String text) {
//        return eventRepository.findAllB(text);
//    }
//
//    @Override
//    public List<SavedBooking> getSavedBookings() {
//        return eventRepository.getSavedBookings();
//    }
//
//    @Override
//    public void addBooking(String evName, int numTickets) {
//        eventRepository.addBooking(evName, numTickets);
//    }
//
//
//    //DODADOV LONG ID za edit
//    @Override
//    public Optional<Event> save(Long id, String name, String description, double popularityScore, Long locationId) {
//        Location location = locationRepository.findById(locationId).orElse(null);
//    // DODADOV IF USLOV
//
//        if (id != null) {
//            // Ако ID-то е дадено, барај го настанот за ажурирање
//            Event existingEvent = eventRepository.findById(id).orElse(null);
//            if (existingEvent != null) {
//                existingEvent.setName(name);
//                existingEvent.setDescription(description);
//                existingEvent.setPopularityScore(popularityScore);
//                existingEvent.setLocation(location);
//                return Optional.of(existingEvent);
//            }
//        }
//
//        return eventRepository.save(id, name, description, popularityScore, location);
//    }
//
//    //Delete
//    @Override
//    public void deleteById(Long id) {
//        eventRepository.deleteById(id);
//    }
//
//    @Override
//    public Optional<Event> findById(Long id) {
//        return eventRepository.findById(id);
//    }
//}

//package mk.finki.ukim.mk.lab.service.impl;
//
//import mk.finki.ukim.mk.lab.model.Event;
//import mk.finki.ukim.mk.lab.model.Location;
//import mk.finki.ukim.mk.lab.service.EventService;
//import mk.finki.ukim.mk.lab.repository.jpa.EventRepositoryjpa;
//import mk.finki.ukim.mk.lab.repository.jpa.LocationRepositoryjpa;
//import org.springframework.stereotype.Service;
//
//import java.util.List;
//import java.util.Optional;
//
//@Service
//public class EventServiceImpl implements EventService {
//
//    private final EventRepositoryjpa eventRepository;
//    private final LocationRepositoryjpa locationRepository;
//
//    public EventServiceImpl(EventRepositoryjpa eventRepository, LocationRepositoryjpa locationRepository) {
//        this.eventRepository = eventRepository;
//        this.locationRepository = locationRepository;
//    }
//
//    @Override
//    public List<Event> listAll() {
//        return eventRepository.findAll(); // Методот е веќе имплементиран во JpaRepository
//    }
//
//    @Override
//    public List<Event> searchEvents(String text) {
//        return eventRepository.findAll().stream()
//                .filter(event -> event.getName().toLowerCase().contains(text.toLowerCase()) ||
//                        event.getDescription().toLowerCase().contains(text.toLowerCase()))
//                .toList();
//    }
//
//    @Override
//    public Optional<Event> save(Long id, String name, String description, double popularityScore, Long locationId) {
//        // Наоѓање на локација според ID
//        Optional<Location> locationOpt = locationRepository.findById(locationId);
//        if (locationOpt.isEmpty()) {
//            throw new RuntimeException("Location not found");
//        }
//        Location location = locationOpt.get();
//
//        // Проверка дали е за ажурирање или креирање
//        Event event;
//        if (id != null) {
//            event = eventRepository.findById(id).orElseThrow(() -> new RuntimeException("Event not found"));
//            event.setName(name);
//            event.setDescription(description);
//            event.setPopularityScore(popularityScore);
//            event.setLocation(location);
//        } else {
//            event = new Event(name, description, popularityScore, location);
//        }
//
//        return Optional.of(eventRepository.save(event));
//    }
//
//    @Override
//    public void deleteById(Long id) {
//        eventRepository.deleteById(id); // Методот е имплементиран од JpaRepository
//    }
//
//    @Override
//    public Optional<Event> findById(Long id) {
//        return eventRepository.findById(id); // Методот е имплементиран од JpaRepository
//    }
//
//    @Override
//    public List<Event> getSavedBookings() {
//        throw new UnsupportedOperationException("Not implemented"); // Можеш да го избришеш или имплементираш
//    }
//
//    @Override
//    public void addBooking(String evName, int numTickets) {
//        throw new UnsupportedOperationException("Not implemented"); // Можеш да го избришеш или имплементираш
//    }
//}


package mk.finki.ukim.mk.lab.service.impl;

import mk.finki.ukim.mk.lab.model.Event;
import mk.finki.ukim.mk.lab.model.Location;
import mk.finki.ukim.mk.lab.model.SavedBooking;
import mk.finki.ukim.mk.lab.repository.jpa.EventRepositoryjpa;
import mk.finki.ukim.mk.lab.repository.jpa.LocationRepositoryjpa;
import mk.finki.ukim.mk.lab.service.EventService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class EventServiceImpl implements EventService {

    private final EventRepositoryjpa eventRepository;
    private final LocationRepositoryjpa locationRepository;

    public EventServiceImpl(EventRepositoryjpa eventRepository,
                            LocationRepositoryjpa locationRepository) {
        this.eventRepository = eventRepository;
        this.locationRepository = locationRepository;
    }

    @Override
    public List<Event> listAll() {
        return eventRepository.findAll();
    }

    @Override
    public List<Event> searchEvents(String text) {
        // Имплементација за пребарување на настани
        return eventRepository.findAll()
                .stream()
                .filter(event -> event.getName().toLowerCase().contains(text.toLowerCase()) ||
                        event.getDescription().toLowerCase().contains(text.toLowerCase()))
                .toList();
    }

    @Override
    public List<SavedBooking> getSavedBookings() {
        // Врати ја имплементацијата на зачуваните резервации ако ги имаш.
        // Ако не користиш вистинска база за SavedBooking, можеш да го вратиш ова празно.
        return List.of(); // или имплементирај соодветна логика
    }

    @Override
    public void addBooking(String evName, int numTickets) {
        // Имплементирај логика за додавање на резервации ако користиш
    }

    @Override
    public Optional<Event> save(Long id, String name, String description, double popularityScore, Long locationId) {
        Optional<Location> locationOpt = locationRepository.findById(locationId);
        if (locationOpt.isEmpty()) {
            throw new RuntimeException("Location not found");
        }
        Location location = locationOpt.get();

        Event event;
        if (id != null) {
            // Update постоечки настан
            event = eventRepository.findById(id).orElseThrow(() -> new RuntimeException("Event not found"));
            event.setName(name);
            event.setDescription(description);
            event.setPopularityScore(popularityScore);
            event.setLocation(location);
        } else {
            // Креирај нов настан
            event = new Event(name, description, popularityScore, location);
        }
        return Optional.of(eventRepository.save(event));
    }

    @Override
    public void deleteById(Long id) {
        eventRepository.deleteById(id);
    }

    @Override
    public Optional<Event> findById(Long id) {
        return eventRepository.findById(id);
    }



}
