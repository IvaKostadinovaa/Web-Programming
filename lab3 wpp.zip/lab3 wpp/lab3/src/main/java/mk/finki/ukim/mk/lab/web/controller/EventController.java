//package mk.finki.ukim.mk.lab.web.controller;
//
//import jakarta.servlet.http.HttpServletRequest;
//import mk.finki.ukim.mk.lab.model.Event;
//import mk.finki.ukim.mk.lab.model.Location;
//import mk.finki.ukim.mk.lab.service.impl.EventServiceImpl;
//import mk.finki.ukim.mk.lab.service.impl.LocationServiceImpl;
//import org.springframework.stereotype.Controller;
//import org.springframework.ui.Model;
//import org.springframework.web.bind.annotation.*;
//
//import java.util.List;
//import java.util.Objects;
//
//@Controller
//@RequestMapping("/events/events-list")
//public class EventController {
//    private final EventServiceImpl eventService;
//    private final LocationServiceImpl locationService;
//
//    public EventController(EventServiceImpl eventService, LocationServiceImpl locationService) {
//        this.eventService = eventService;
//        this.locationService = locationService;
//    }
//
//    // TODO: need exceptions (prob next lab)
//    @GetMapping
//    public String getEventsPage(@RequestParam(required = false) String error, Model model, HttpServletRequest req) {
//        List<Event> eventList;
//        String searchName = req.getParameter("searchName");
//        String minRating =req.getParameter("minRating");
//
//        if (searchName != null && minRating != null && !Objects.equals(minRating, "")) {
//            eventList = eventService.searchEvents(searchName).stream()
//                    .filter(event -> event.getPopularityScore() >= Double.parseDouble(minRating))
//                    .toList();
//        } else if (minRating != null && !Objects.equals(minRating, "")) {
//            eventList = eventService.listAll().stream()
//                    .filter(event -> event.getPopularityScore() >= Double.parseDouble(minRating))
//                    .toList();
//        } else if (searchName != null) {
//            eventList = eventService.searchEvents(searchName);
//        } else {
//            eventList = eventService.listAll();
//        };
//
//        model.addAttribute("events", eventList);
//        return "listEvents";
//    }
//
//    //Delete
//    @PostMapping("/delete/{id}")
//    public String deleteEvent(@PathVariable Long id) {
//        this.eventService.deleteById(id);
//        return "redirect:/events/events-list";
//    }
//
//    //Add new event, овој метод се повикува и ја прикажува страницата add-event.html
//    @GetMapping("/add-form")
//    public String addEventPage(Model model) {
//        List<Location> locationList = locationService.listAll();
//        model.addAttribute("locations", locationList);
//        return "add-event";
//    }
//
//    //edit-editEventPage
//    @GetMapping("/edit-form/{id}")
//    public String editEventPage(Model model, @PathVariable Long id) {
//        if (this.eventService.findById(id).isPresent()) {
//            Event event = this.eventService.findById(id).get();
//            List<Location> locationList = locationService.listAll();
//            model.addAttribute("locations", locationList);
//            model.addAttribute("event", event);
//            return "add-event";
//        }
//        return "redirect:/events?error=EventNotFound";
//    }
//
//    @GetMapping("/event-details/{id}")
//    public String eventDetailsPage(Model model, @PathVariable Long id) {
//        if (this.eventService.findById(id).isPresent()) {
//            Event event = this.eventService.findById(id).get();
//            model.addAttribute("event", event);
//            return "event-details";
//        }
//        return "redirect:/events?error=EventNotFound";
//    }
//
//    //edit-saveEvent
//    @PostMapping("/add")
//    public String saveEvent(
//            //Long id go dodadov
//            @RequestParam(required = false) Long id,  // Прифати го ID-то како параметар
//
//            @RequestParam String name,
//            @RequestParam String description,
//            @RequestParam double popularityScore,
//            @RequestParam Long location
//    ) {
//        //id go dodadov
//        //Овој метод ги користи параметрите од формата add-event.html и го повикува сервисот save,
//        // кој креира нов настан и го додава во листата
//        this.eventService.save(id, name, description, popularityScore, location);
//        return "redirect:/events/events-list";
//
//    }
//}
//

package mk.finki.ukim.mk.lab.web.controller;

import jakarta.servlet.http.HttpServletRequest;
import mk.finki.ukim.mk.lab.model.Event;
import mk.finki.ukim.mk.lab.model.Location;
import mk.finki.ukim.mk.lab.service.EventService;
import mk.finki.ukim.mk.lab.service.LocationService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Objects;

@Controller
@RequestMapping("/events/events-list")
public class EventController {

    private final EventService eventService;
    private final LocationService locationService;

    public EventController(EventService eventService, LocationService locationService) {
        this.eventService = eventService;
        this.locationService = locationService;
    }

//    @GetMapping
//    public String getEventsPage(@RequestParam(required = false) String error, Model model, HttpServletRequest req) {
//        List<Event> eventList;
//        String searchName = req.getParameter("searchName");
//        String minRating = req.getParameter("minRating");
//
//        if (searchName != null && minRating != null && !Objects.equals(minRating, "")) {
//            eventList = eventService.searchEvents(searchName).stream()
//                    .filter(event -> event.getPopularityScore() >= Double.parseDouble(minRating))
//                    .toList();
//        } else if (minRating != null && !Objects.equals(minRating, "")) {
//            eventList = eventService.listAll().stream()
//                    .filter(event -> event.getPopularityScore() >= Double.parseDouble(minRating))
//                    .toList();
//        } else if (searchName != null) {
//            eventList = eventService.searchEvents(searchName);
//        } else {
//            eventList = eventService.listAll();
//        }
//
//        model.addAttribute("events", eventList);
//        model.addAttribute("error", error);
//        return "listEvents";
//    }
@GetMapping
public String getEventsPage(@RequestParam(required = false) String searchName,
                            @RequestParam(required = false) String minRating,
                            Model model) {
    List<Event> events;

    if (searchName != null && minRating != null && !minRating.isEmpty()) {
        double minRatingValue = Double.parseDouble(minRating);
        events = eventService.listAll().stream()
                .filter(event -> event.getName().toLowerCase().contains(searchName.toLowerCase()) ||
                        event.getDescription().toLowerCase().contains(searchName.toLowerCase()))
                .filter(event -> event.getPopularityScore() >= minRatingValue)
                .toList();
    } else if (minRating != null && !minRating.isEmpty()) {
        double minRatingValue = Double.parseDouble(minRating);
        events = eventService.listAll().stream()
                .filter(event -> event.getPopularityScore() >= minRatingValue)
                .toList();
    } else if (searchName != null && !searchName.isEmpty()) {
        events = eventService.searchEvents(searchName);
    } else {
        events = eventService.listAll();
    }

    model.addAttribute("events", events);
    return "listEvents";
}




    @PostMapping("/delete/{id}")
    public String deleteEvent(@PathVariable Long id) {
        this.eventService.deleteById(id);
        return "redirect:/events/events-list";
    }

//    @GetMapping("/add-form")
//    public String addEventPage(Model model) {
//        List<Location> locationList = locationService.listAll();
//        model.addAttribute("locations", locationList);
//        return "add-event";
//    }
//
//    @GetMapping("/edit-form/{id}")
//    public String editEventPage(@PathVariable Long id, Model model) {
//        if (this.eventService.findById(id).isPresent()) {
//            Event event = this.eventService.findById(id).get();
//            List<Location> locationList = locationService.listAll();
//            model.addAttribute("locations", locationList);
//            model.addAttribute("event", event);
//            return "add-event";
//        }
//        return "redirect:/events/events-list?error=EventNotFound";
//    }

    @GetMapping("/add-form")
    public String addEventPage(Model model) {
        model.addAttribute("locations", locationService.listAll());
        return "add-event";
    }

    @GetMapping("/edit-form/{id}")
    public String editEventPage(@PathVariable Long id, Model model) {
        Event event = eventService.findById(id).orElseThrow(() -> new RuntimeException("Event not found"));
        model.addAttribute("event", event);
        model.addAttribute("locations", locationService.listAll());
        return "add-event";
    }

//    @PostMapping("/save")
//    public String saveEvent(
//            @RequestParam(required = false) Long id,
//            @RequestParam String name,
//            @RequestParam String description,
//            @RequestParam double popularityScore,
//            @RequestParam Long locationId) {
//
//        this.eventService.save(id, name, description, popularityScore, locationId);
//        return "redirect:/events/events-list";
//    }

    @PostMapping("/add")
    public String saveEvent(
            @RequestParam(required = false) Long id,
            @RequestParam String name,
            @RequestParam String description,
            @RequestParam double popularityScore,
            @RequestParam Long location) {
        this.eventService.save(id, name, description, popularityScore, location);
        return "redirect:/events/events-list";
    }


    @GetMapping("/event-details/{id}")
    public String eventDetailsPage(@PathVariable Long id, Model model) {
        if (this.eventService.findById(id).isPresent()) {
            Event event = this.eventService.findById(id).get();
            model.addAttribute("event", event);
            return "event-details";
        }
        return "redirect:/events/events-list?error=EventNotFound";
    }
}
