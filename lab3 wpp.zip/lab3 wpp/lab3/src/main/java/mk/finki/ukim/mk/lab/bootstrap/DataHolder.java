package mk.finki.ukim.mk.lab.bootstrap;

import jakarta.annotation.PostConstruct;
import mk.finki.ukim.mk.lab.model.Event;
import mk.finki.ukim.mk.lab.model.Location;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class DataHolder {
    public static List<Event> eventList = new ArrayList<>();
    public static List<Location> locationList = new ArrayList<>();

//    @PostConstruct
//    public void init() {
//        locationList.add(new Location("City Arena", "Main Street 1", "5000", "Large arena for sports events"));
//        locationList.add(new Location("Green Park", "Park Avenue 15", "1500", "Outdoor space for concerts and festivals"));
//        locationList.add(new Location("Tech Hub", "Innovation Road 10", "300", "Conference hall for tech events"));
//        locationList.add(new Location("Art Gallery", "Museum Street 22", "100", "Exclusive space for art exhibitions"));
//        locationList.add(new Location("Sky Lounge", "Rooftop Blvd 5", "200", "Rooftop lounge with a great city view"));
//
//        eventList.add(new Event("Rock Concert", "An electrifying night with top rock bands", 8.5, locationList.get(0)));
//        eventList.add(new Event("Food Festival", "Taste dishes from around the world", 7.8, locationList.get(1)));
//        eventList.add(new Event("Tech Conference 2024", "Latest trends in technology and innovation", 9.0, locationList.get(2)));
//        eventList.add(new Event("Art Exhibition", "Featuring works from renowned contemporary artists", 6.5, locationList.get(3)));
//        eventList.add(new Event("Jazz Night", "Live jazz performance with international artists", 8.0, locationList.get(4)));
//        eventList.add(new Event("Startup Pitch Day", "Innovative startups pitch to investors", 9.5, locationList.get(2)));
//        eventList.add(new Event("Film Screening: Classic Cinema", "Enjoy a night of classic films", 7.2, locationList.get(3)));
//        eventList.add(new Event("Bible study", "Bible session in nature", 8.9, locationList.get(1)));
//        eventList.add(new Event("Basketball Championship", "Top teams compete for the national title", 10.0, locationList.get(0)));
//        eventList.add(new Event("Wine Tasting", "Sample premium wines from local vineyards", 7.5, locationList.get(4)));
//    }
}
